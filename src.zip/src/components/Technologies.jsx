import React from 'react'

const Technologies = () => {
  return (
    <div>Technologies</div>
  )
}

export default Technologies